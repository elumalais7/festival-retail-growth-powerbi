# Festival Retail Growth Analysis (Power BI)

A beginner-friendly retail analytics portfolio project using **synthetic festive-season sales data** for Diwali and New Year. The project demonstrates how to import, clean, model, analyse, and visualise retail performance with Power BI.

> **Important:** This is a learning/demo project. The included data is synthetic, not official Vritika challenge data or real company data. Confirm the challenge's official submission rules before submitting.

## Project objectives
- Compare Diwali and New Year sales and profit.
- Find profitable product categories and sales channels.
- Track discounts, returns, revenue, and profit margin.
- Build an interactive Power BI dashboard.
- Turn findings into practical retail growth recommendations.

## Repository structure

```text
festival-retail-growth-powerbi/
├── data/
│   └── festival_retail_sales_sample.csv
├── docs/
│   ├── PROJECT_REPORT.md
│   ├── DASHBOARD_BUILD_GUIDE.md
│   └── SUBMISSION_CHECKLIST.md
├── powerbi/
│   └── DAX_MEASURES.md
├── .gitignore
├── LICENSE
└── README.md
```

## Tools
- Power BI Desktop (Windows)
- Power Query
- DAX
- CSV dataset

## Quick start
1. Download or clone this repository.
2. Open Power BI Desktop.
3. Select **Home → Get data → Text/CSV**.
4. Import `data/festival_retail_sales_sample.csv`.
5. Select **Transform Data** and check data types (especially `OrderDate`).
6. Select **Close & Apply**.
7. Rename the imported table to `FestivalSales`.
8. Create the measures in [`powerbi/DAX_MEASURES.md`](powerbi/DAX_MEASURES.md).
9. Build the report using [`docs/DASHBOARD_BUILD_GUIDE.md`](docs/DASHBOARD_BUILD_GUIDE.md).
10. Update the report with screenshots and verified results before submission.

## Data fields
| Field | Meaning |
|---|---|
| OrderID | Sample order-line identifier |
| OrderDate | Sample transaction date |
| Festival | Diwali or New Year |
| City | Sample retail city |
| SalesChannel | In-store or Online |
| Category / Product | Product grouping and name |
| Quantity | Units sold |
| UnitPriceINR | Unit selling price before discount |
| DiscountPct | Discount percentage |
| GrossSalesINR | Quantity × unit price |
| DiscountAmountINR | Discount value |
| SalesAfterDiscountINR | Sales after discount, before returns |
| UnitCostINR / TotalCostINR | Simplified product cost |
| Returned | Whether the sample order line was returned |
| ReturnAmountINR | Revenue amount reversed for returns |
| NetRevenueINR | Revenue after returns |
| ProfitINR | Simplified profit after returns and product cost |

## Business questions
1. Which festival generated the most net revenue and profit?
2. Which product category contributed the most profit?
3. Which sales channel performed better?
4. How large are discounts and returns relative to sales?
5. Which products might deserve more stock or a different promotion strategy?

## Accounting assumptions and limitations
- All records are synthetic and generated for demonstration.
- A returned order line reverses the full discounted revenue, while the simplified model leaves its product cost in the calculation. Real return accounting depends on returned inventory condition and accounting policy.
- No advertising spend, inventory snapshots, shipping costs, taxes, or customer-level behaviour are included.
- The generated sample is small and must not be used to claim actual market trends.
- Before final submission, replace the sample data if the challenge provides an official dataset and follow the organisers' rules.

## Suggested GitHub repository description
`Beginner Power BI project analysing synthetic Diwali and New Year retail sales, profit, discounts, returns, and category performance.`

## Suggested GitHub topics
`power-bi`, `powerbi`, `retail-analytics`, `data-analytics`, `dax`, `power-query`, `business-intelligence`, `dashboard`
