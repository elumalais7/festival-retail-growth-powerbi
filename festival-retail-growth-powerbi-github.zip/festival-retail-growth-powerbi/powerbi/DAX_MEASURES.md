# Power BI DAX Measures

After importing the CSV, rename the table to `FestivalSales`. Add each formula using **Modeling → New measure**.

```dax
Net Revenue =
    SUM(FestivalSales[NetRevenueINR])
```

```dax
Total Profit =
    SUM(FestivalSales[ProfitINR])
```

```dax
Total Cost =
    SUM(FestivalSales[TotalCostINR])
```

```dax
Total Orders =
    DISTINCTCOUNT(FestivalSales[OrderID])
```

```dax
Total Quantity =
    SUM(FestivalSales[Quantity])
```

```dax
Discount Value =
    SUM(FestivalSales[DiscountAmountINR])
```

```dax
Return Value =
    SUM(FestivalSales[ReturnAmountINR])
```

```dax
Returned Lines =
    CALCULATE(
        COUNTROWS(FestivalSales),
        FestivalSales[Returned] = "Yes"
    )
```

```dax
Return Rate =
    DIVIDE(
        [Returned Lines],
        COUNTROWS(FestivalSales),
        0
    )
```

```dax
Profit Margin =
    DIVIDE([Total Profit], [Net Revenue], 0)
```

```dax
Average Order Revenue =
    DIVIDE([Net Revenue], [Total Orders], 0)
```

## Formatting
- `Net Revenue`, `Total Profit`, `Total Cost`, `Discount Value`, `Return Value`, and `Average Order Revenue`: Currency (₹ INR), 0–2 decimal places.
- `Profit Margin` and `Return Rate`: Percentage.
- `Total Orders`, `Total Quantity`, `Returned Lines`: Whole number.

## Optional measure: gross sales

```dax
Gross Sales =
    SUM(FestivalSales[GrossSalesINR])
```

## Important note
`OrderID` is a unique sample order-line identifier in this dataset, so `Total Orders` currently counts these records. In a real dataset with multiple lines per order, use the retailer's true order identifier and confirm the intended definition.
