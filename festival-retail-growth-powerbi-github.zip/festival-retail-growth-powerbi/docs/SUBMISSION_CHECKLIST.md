# Submission Checklist

- [ ] Read the official challenge brief, deadline, and permitted data/tool rules.
- [ ] Confirm whether organisers require a provided dataset or specific deliverable format.
- [ ] Import the CSV into Power BI and validate data types.
- [ ] Add and format all DAX measures.
- [ ] Build the dashboard and test slicers.
- [ ] Verify all values in the report against Power BI.
- [ ] Add a dashboard screenshot to the repository if permitted.
- [ ] Clearly label all synthetic/demo data.
- [ ] Remove personal information and secrets from repository files.
- [ ] Include the PBIX only if you have created it in Power BI Desktop and file size/rules permit.
- [ ] Do not claim this practice project uses official company data or guarantees internship selection.
