# Dashboard Build Guide

## 1. Import and prepare the data
1. Open Power BI Desktop.
2. Select **Home → Get data → Text/CSV**.
3. Import `data/festival_retail_sales_sample.csv`.
4. Select **Transform Data**.
5. Confirm `OrderDate` is **Date**; quantity and money columns are numeric; `Festival`, `City`, `SalesChannel`, `Category`, `Product`, and `Returned` are text.
6. Select **Close & Apply**.
7. Rename the table to `FestivalSales`.

## 2. Add measures
Create the DAX measures listed in `powerbi/DAX_MEASURES.md`.

## 3. Create one report page
Page name: **Festival Growth Dashboard**

Suggested layout:
- Top row: title and slicers for Festival, City, Category, SalesChannel.
- KPI cards: Net Revenue, Total Profit, Profit Margin, Total Orders, Return Rate.
- Middle row:
  - Clustered column chart: Axis `Festival`, Values `Net Revenue`.
  - Bar chart: Axis `Category`, Values `Total Profit`.
- Bottom row:
  - Donut chart: Legend `SalesChannel`, Values `Net Revenue`.
  - Line chart: X-axis `OrderDate`, Y-axis `Net Revenue`.
  - Table: `Product`, `Total Quantity`, `Net Revenue`, `Total Profit`, `Profit Margin` (if the margin measure is added to the table).
- Keep titles clear, use consistent formatting, and avoid overcrowding.

## 4. Visual field mapping
| Visual | Field wells |
|---|---|
| Card | `Net Revenue` |
| Card | `Total Profit` |
| Card | `Profit Margin` |
| Card | `Total Orders` |
| Card | `Return Rate` |
| Clustered column chart | X-axis: `Festival`; Y-axis: `Net Revenue` |
| Bar chart | Y-axis: `Category`; X-axis: `Total Profit` |
| Donut chart | Legend: `SalesChannel`; Values: `Net Revenue` |
| Line chart | X-axis: `OrderDate`; Y-axis: `Net Revenue` |
| Table | `Product`, `Total Quantity`, `Net Revenue`, `Total Profit` |

## 5. Check interactivity
- Use the Festival, City, Category, and SalesChannel slicers.
- Click each slicer and confirm the KPI cards and charts respond.
- Sort the profit-by-category chart by `Total Profit` descending.
- Format currency measures as INR and percentages as percentages.
- Make sure the date chart uses a continuous or appropriate date axis.

## 6. Save and document
Save the Power BI file as `Festival_Retail_Growth_Analysis.pbix` locally. The PBIX is a binary Power BI Desktop file, so create it in Power BI Desktop; this repository provides the dataset, DAX, and build guide, not a prebuilt PBIX.
Take a screenshot of the finished dashboard and add it to the README or the final report if challenge rules allow.
