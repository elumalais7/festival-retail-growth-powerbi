# Project Report: Festival Retail Growth Analysis Using Power BI

**Project type:** Beginner business intelligence / retail analytics  
**Data:** Synthetic sample dataset, 120 order-line records  
**Festivals:** Diwali and New Year  
**Tools:** Power BI Desktop, Power Query, DAX

> This is a practice/portfolio report based on generated data. It is not official Vritika challenge data and does not describe a real retailer.

## 1. Executive summary

This project demonstrates how Power BI can be used to analyse festive retail performance. It tracks net revenue after returns, simplified profit, discounts, returns, product categories, cities, and sales channels.

In the generated sample, net revenue is **₹408,760**, simplified profit is **₹134,830**, and profit margin is **33.0%**. The highest-profit category is **Home & Kitchen**; the highest-profit festival is **Diwali**; and the highest-profit channel is **In-store** in this particular sample.

## 2. Business problem

Festive promotions can increase sales, but heavy discounts and returns may reduce profitability. A retailer needs a dashboard to compare festival periods, find profitable categories, understand channel performance, and make better promotion and inventory decisions.

## 3. Objectives

- Compare Diwali and New Year net revenue and profit.
- Identify profitable product categories.
- Compare online and in-store performance.
- Track discounts, returns, and profit margin.
- Suggest data-led improvements for future festive campaigns.

## 4. Dataset

The CSV contains 120 synthetic order-line records. Key columns include order ID, order date, festival, city, sales channel, category, product, quantity, unit price, discount percentage, gross sales, discount amount, sales after discount, product cost, return status, return amount, net revenue, and profit.

## 5. Results from the sample

| Metric | Sample result |
|---|---:|
| Order-line records | 120 |
| Gross sales | ₹469,450 |
| Discount value | ₹46,172 |
| Sales after discount, before returns | ₹423,278 |
| Return value | ₹14,518 |
| Net revenue after returns | ₹408,760 |
| Simplified profit | ₹134,830 |
| Profit margin | 33.0% |

### Festival comparison

- **Diwali:** net revenue ₹203,355; simplified profit ₹68,345; 64 order lines.
- **New Year:** net revenue ₹205,405; simplified profit ₹66,485; 56 order lines.

### Category comparison

- **Home & Kitchen:** net revenue ₹154,580; simplified profit ₹52,350.
- **Electronics:** net revenue ₹135,780; simplified profit ₹37,980.
- **Clothing:** net revenue ₹64,340; simplified profit ₹23,910.
- **Gifts:** net revenue ₹54,060; simplified profit ₹20,590.

### Channel comparison

- **In-store:** net revenue ₹242,558; simplified profit ₹82,332.
- **Online:** net revenue ₹166,202; simplified profit ₹52,498.

These figures describe only the generated sample. They are not evidence of real market trends.

## 6. Dashboard design

The planned report page contains:
- KPI cards for net revenue, profit, profit margin, order count, and return rate.
- Net revenue by festival.
- Profit by category.
- Net revenue by sales channel.
- Net revenue over time.
- Product-level summary table.
- Slicers for festival, city, category, and sales channel.

See [`DASHBOARD_BUILD_GUIDE.md`](DASHBOARD_BUILD_GUIDE.md) for the visual field mappings and build steps.

## 7. Business recommendations

1. **Prioritise profitable categories.** Use both profit and revenue to plan festive campaigns rather than choosing products based on sales alone.
2. **Test discount levels.** Compare profit margin before and after promotions; avoid assuming the largest discount is best.
3. **Investigate returns.** Review reasons for returned products and improve product information, packaging, and quality checks where appropriate.
4. **Allocate channel budgets carefully.** Compare category and profit performance for online and in-store sales before shifting advertising spend.
5. **Plan inventory with evidence.** Use sales by product and date to reduce stockouts and excess stock.

These are recommendations to test with real business data, not guaranteed outcomes.

## 8. Limitations and assumptions

- The data is synthetic and contains only 120 records.
- The sample does not include marketing costs, shipping costs, tax, stock availability, or customer behaviour.
- A returned order line reverses the full discounted revenue while product cost remains in the simplified profit calculation. Actual accounting treatment should follow the retailer's policies and the condition of returned inventory.
- Sample trends may not generalise to a real retailer.
- Replace sample data with official challenge data if provided and permitted by the organisers.

## 9. Conclusion

This project demonstrates a basic analytics workflow: import a CSV, clean data in Power Query, create DAX measures, build interactive visuals, and translate results into business recommendations. The next step is to finish the dashboard in Power BI Desktop, add a screenshot, and verify the final submission against the challenge rules.
